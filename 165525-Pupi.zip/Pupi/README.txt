Pupi is an Xfce window manager theme for high DPI / Retina systems.

The buttons and most transparencies are based on the Kokodi theme by Olivier
Fourdan  but have been scaled an extra 50%.

The 'sources' directory contains the xfc files that can be openend with GIMP.
The 'Kokodi' directory contains the original Kokodi theme.

The colors of this theme are similar to the ones of the Clearlooks GTK theme:
 * Base active color: #82b2dd
 * Base inactive color: #e8e7e6

Installation instructions:
 * Decompress the zip file
 * Copy the Pupi folder into the system themes directory (in Debian it is located in /usr/share/themes)
 * Open the Window Manager and it should be listed in there

Enjoy!
--
Pupi